This shapefile includes the International Best Track Archive for Climate Stewardship storm track points for the North American basin.

The original link to these data is: https://www.ncei.noaa.gov/data/international-best-track-archive-for-climate-stewardship-ibtracs/v04r01/access/shapefile/IBTrACS.NA.list.v04r01.points.zip. However, the shapefile contained in that Zip file has a name that is not compatbile with ArcGIS Pro or ArcPy. 

The shapefile here is that exact file, as of September 2011, renamed from "IBTrACS.NA.list.v04r01.points.shp" to "IBTrACS_NA.shp".

John Fay
September 2025